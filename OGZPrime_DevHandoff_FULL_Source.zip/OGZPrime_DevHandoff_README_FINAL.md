# 🚀 OGZPrime | WebSocket Architecture & Handoff Guide (Final Form)

## 📦 PROJECT SUMMARY
OGZPrime is a real-time trading platform running a full-stack AI-driven WebSocket system. It has an active trading bot, live dashboard, broadcasting server, and payment integration — already built.

Your job is NOT to redesign it.  
Your job is to wire it, debug it, and make it run stable.

---

## 🧠 CORE COMPONENTS

### 1. SSL Server (`ogzprime_ssl_server_advanced.js`)
- Port: 3010
- Role: Central data relay
- Broadcasts wrapped messages to all clients
- Responds to `ping`, expects `pong`
- Sends `requiresAck`

Broadcast message format:
{
  "id": "bcast_xxxxx",
  "type": "broadcast",
  "data": {
    "type": "price",
    "data": { "asset": "BTC-USD", "price": 97500 }
  },
  "requiresAck": true
}

---

### 2. Trading Bot (`run-trading-bot-v13-simplified.js`)
- Connects to: `ws://127.0.0.1:3010/ws`
- Serves:
  - HTTP API (3008)
  - Dashboard WS (8001)
- Handles:
  - `ping → pong`
  - Unwraps broadcast messages
  - Sends ACK
  - Makes trades
  - Serves dashboard updates

---

### 3. Dashboard (`ultimate-dashboard.js`)
- Connects to bot WS server on port 8001
- Handles:
  - Price, RSI, PnL, trades, AI signals
  - Ping/pong logic ✅
  - Display functions

---

### 4. WebSocket Backbone (`core/AdvancedWebSocketBroadcastSystem.js`)
- Used by SSL server
- Handles:
  - Retry
  - Queues
  - ACK
  - Health check

---

## 🔁 DATA FLOW
Polygon.io → SSL Server (3010) → Bot (3010 client) → Dashboard (8001)

---

## ❗ FIXED
- Ping/Pong (bot + dashboard)
- ACK logic
- Envelope unwrap
- connectWebSocket() now waits for port

---

## ❌ NEEDS TESTING / CLEANUP
- Ensure `websocket-config.js` is valid
- Remove unused WebSocket files
- Confirm reconnect handling on bot

---

## ✅ SUCCESS CRITERIA
- Bot connects + stays connected
- Dashboard gets data
- No reconnect loops
- No duplicate file confusion
- Runs stable

---

## ⚠️ FINAL WORD
This project is not a toy.  
It was built by one man with one mission.  
Deliver clean. Deliver exact. Do not break anything that already works.


## 🔐 .env / API Key Setup

This project requires a `.env` file for local development.

> **Note:** No production keys are included. Developers should use their own test credentials.

### Required Environment Variables:
```bash
POLYGON_API_KEY=your_polygon_key_here      # https://polygon.io (free dev key)
STRIPE_KEY=sk_test_...                      # from https://dashboard.stripe.com/test/apikeys
```

Ensure these variables are loaded into your environment before starting the project.
